#ASSIGNMENT
# TOPIC: Stock Market Platform
#SINGLE INHERITANCE
'''class investors:
    n=int(input("Enter the number of investors:"))
    for i in range(n):
        demat_no=input("Enter the 6-digit demat account number:")
        name=input("Enter Investor name:")
        PanNo=input("Enter the 9 digit pan number:")
        upi_id=input("Enter the active  UPI id(1234567890@abc):")
        phone=int(input("Enter the phone number:"))
inves=investors()
class fund_details(investors):
    for i in range(inves.n):
        fund_amt=int(input("Enter the amount to be added to the funds "))
def display():
    for i in range(inves.n):
        print("THE INVESTOR DETAILS ARE AS FOLLOWS:")
        print("____________________________________________________________________________")
        print("ACC NO       NAME        PAN NO   UPI ID    PHONE   FUNDS")
        print("_____________________________________________________________________________")
        print(inves.demat_no,'',inves.name,'',inves.PanNo,'',inves.upi_id,'',inves.phone,'',fund_details.fund_amt)
display()
fund_details()'''

#MULTIPLE INHERITANCE
'''class buyers:
    n=int(input("Enter the number of buyers:"))
    for i in range(n):
        demat_no=input("Enter the 6-digit demat account number:")
        name=input("Enter buyer name:")
        orderId=int(input("Enter the order Id"))
        holdstock=input("Enter the stock your holding")
        shares=int(input("Enter the total number of units brought"))
        pur_amt=int(input("Enter the amount at which you brought the share(per unit price)"))
        total=shares*pur_amt
        pricetobesold=int(input("Enter the price per unit at which you want to sell the stock"))
buy=buyers()

class sellers:
    n=int(input("Enter the number of sellers:"))
    for i in range(n):
        demat_no=input("Enter the 6-digit demat account number:")
        name=input("Enter seller name:")
        print("The avaiable stocks are :")
        stockdic={"HDFC":560,"TCS":780,"UCO":340,"MAHINDRAMOTORS": 900,"ATC":670,"BIRLA": 950,"TVS":460,"UTHKARSH":600,"PWS":400,"ICIC":890}
        print(stockdic)
        stockname=input("Enter the stock you would like to purchase")
        units=int(input("Enter the total number of shares you want to purchase"))
        amt=int(input("Enter the per unit amount of the selected order as shown above"))
        total_amt=units*amt
        print("THE TOTAL AMOUNT PAYABLE ",total_amt)
    
sell=sellers()
class tradepoint(buyers,sellers):
    def trade():
        if(buy.holdstock==sell.stockname and buy.shares>=sell.units and buy.pricetobesold>=sell.amt):
            print("The Stock ",sell.stockname,"is sold to ",sell.name,"with order Id",buy.orderId,"at a trading price of",sell.amt)
            print("______________________________________________________________________")
            print("ACC NO       NAME         STOCK NAME     NO OF UNITS    AMOUNT    STATUS")
            print("_____________________________________________________________________________")
            print(sell.demat_no,'','',sell.name,'','',sell.stockname,'','',sell.units,'','',sell.total_amt,'','',"STOCK BOOKED SUCCESSFULLY")
        else:
            print("Booking cancelled")
    def trade1():
        if(buy.holdstock==sell.stockname and buy.shares>=sell.units and buy.pricetobesold>=sell.amt):
            print("STOCK SOLD SUCCESSFULLY")
            profit=(sell.total_amt - buy.total)
            print("You have made a total profit of Rs.",profit,) 
    trade()
    trade1()
tradepoint()'''

#MULTI - LEVEL INHERITANCE:

'''class Stock:
    def __init__(self, symbol, price):
        self.symbol = symbol
        self.price = price

    def calculate_value(self, quantity):
        return self.price * quantity

class TechStock(Stock):
    def __init__(self, symbol, price, growth_rate):
        super().__init__(symbol, price)
        self.growth_rate = growth_rate

    def calculate_dividend(self, quantity):
        return self.price * self.growth_rate * quantity

class HighTechStock(TechStock):
    def __init__(self, symbol, price, growth_rate, volatility):
        super().__init__(symbol, price, growth_rate)
        self.volatility = volatility

    def calculate_volatility_adjusted_value(self, quantity):
        volatility_factor = 1 - (self.volatility / 100)
        return self.calculate_value(quantity) * volatility_factor


google = HighTechStock("GOOGL", 2800.0, 0.08, 15.0)

quantity = 200

google_value = google.calculate_value(quantity)
google_dividend = google.calculate_dividend(quantity)
google_volatility_adjusted_value = google.calculate_volatility_adjusted_value(quantity)

print(f"{google.symbol} Value: ${google_value}")
print(f"{google.symbol} Dividend: ${google_dividend}")
print(f"{google.symbol} Volatility-Adjusted Value: ${google_volatility_adjusted_value:.2f}")'''



#HIERARCHICAL INHERITANCE:

'''class Stock:
    def __init__(self, symbol, price):
        self.symbol = symbol
        self.price = price

    def calculate_value(self, quantity):
        return self.price * quantity

class TechStock(Stock):
    def __init__(self, symbol, price, growth_rate):
        super().__init__(symbol, price)
        self.growth_rate = growth_rate

    def calculate_dividend(self, quantity):
        return self.price * self.growth_rate * quantity

class BankStock(Stock):
    def __init__(self, symbol, price, dividend_yield):
        super().__init__(symbol, price)
        self.dividend_yield = dividend_yield

    def calculate_dividend(self, quantity):
        return self.price * self.dividend_yield * quantity

apple = TechStock("AAPL", 150.0, 0.05)
jpmorgan = BankStock("JPM", 120.0, 0.04)
quantity = int(input("Enter the quantity: "))

apple_value = apple.calculate_value(quantity)
apple_dividend = apple.calculate_dividend(quantity)

jpmorgan_value = jpmorgan.calculate_value(quantity)
jpmorgan_dividend = jpmorgan.calculate_dividend(quantity)

print(f"{apple.symbol} Value: ${apple_value}, Dividend: ${apple_dividend}")
print(f"{jpmorgan.symbol} Value: ${jpmorgan_value}, Dividend: ${jpmorgan_dividend}")'''




    
