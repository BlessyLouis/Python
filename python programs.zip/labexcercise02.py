'''Write a Python program using Recursion
1. to find the greatest common divisor (GCD) of two integers.'''
'''def gcd(num_1,num_2):
    if(num_2==0):
        return num_1
    else:
        return gcd(num_2,num_1 % num_2)
num_1=int(input("Enter first number:"))
num_2=int(input("Enter second number:"))
GCD=gcd(num_1,num_2)
print("GCD of " ,num_1,"and",num_2 ,"is :" )
print(GCD)'''

'''2.to calculate the sum of the positive integers of n+(n-2)+(n-4)... (until n-x =< 0).'''
'''def sum_series(n):
  if n < 1:
    return 0
  else:
    return n + sum_series(n - 2)

n=int(input("Enter a number to print the sum series:"))
print("The sum of the series of ",n,"is")
print(sum_series(n))'''

'''3.to find the nCr = n! / r! (n-r)!'''

def nCr(n, r):
    if r > n:
        return 0
    elif r == 0 or r == n:
        return 1
    else:
        return nCr(n-1, r-1) + nCr(n-1, r)
n = int(input("enter the n value"))
r = int(input("enter the r value"))
print("The combination value of",n,"and",r,"is")
print(nCr(n, r))
