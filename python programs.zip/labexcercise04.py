'''Write Python program

1. to convert a tuple to a string'''

'''tup=("b","l","e","s","s","y")
str=' '
for item in tup:
    str= str + item
print("the string is",str)'''

'''2.to get the 4th element from the last element of a tuple'''
'''tuplenum=(1,2,3,4,5,6)
print("The 4th element from the last element of the tuple is:",tuplenum[-4])'''

'''3. to find repeated items in a tuple.'''
'''tup=(12,12,12,45,17,35,19,19,19)
res_tup=[]
for item in  tup:
    if(item not in res_tup):
        res_tup.append(item)
for elements in res_tup:
    count=tup.count(elements)
    if(count>1):
        print(elements,"is repeated",count,"times")
    else:
        print(elements,"no repetation")'''



'''4. to check whether an element exists within a tuple.'''
'''tup=(101,"blessy","MDS",78,"pass")
print(tup)
x=input("enter the value you would like to check")
if x in tup:
    print("Present")
else:
    print("Not present")'''
    
'''5. to convert a list to a tuple.'''
'''lst=[101,"blessy","MDS",78,"pass"]
print(lst)
newtup=tuple(lst)
print("the tuple is :",newtup)'''

'''6. to reverse a tuple.'''
'''def Reverse(tuples):
    new_tup = tuples[::-1]
    return new_tup
     
tuples = ('z','a','d','f','g','e','e','k')
print(tuples)
print(Reverse(tuples))'''

'''7. to remove an empty tuple(s) from a list of tuples.'''
'''lst=[(),(),('a','b'),(),('a','b','c'),('d','e')]
lst=[t for t in lst if t]
print(" The New list is:",lst)'''

'''8.Write a Python program to calculate the product, multiplying all the numbers in a
given tuple.'''
'''tup=(4,3,2,2,-1,18)
res=1
for item in tup:
    res=res*item

print("The product after multiplying all the elements of the tuple is:",res)'''

'''9.Write a Python program to calculate the average value of the numbers in a
given tuple of tuples.'''
'''Tupnew=((10,10,10,12),(30,45,56,45),(81,80,39,32),(1,2,3,4))
res_lst=[]
for i in range(len(Tupnew)):
    total=0
    for j in range(len(Tupnew)):
        n=len(Tupnew)
        total=total+Tupnew[j][i]
    avg=total/n
    res_lst.append(avg)
print("the average value of the numbers in the tuple is:",res_lst)'''
'''10.Write a Python program to check if a specified element appears in a tuple of tuples.'''
'''tup1=(('Red','white','blue'),('green','pink','purple'),('orange','yellow','olive'))
x="white"
y="olive"
for items in tup1:
    if x in items:
        print("TRUE")
    if y in items:
        print("FALSE")'''
'''SET'''
'''1. Add a list of elements to a set'''
'''lst=[]
for i in range(6):
    num=int(input("Enter the numbers to be added to a set"))
    lst.append(num)
setnew=set(lst)
print("The set is:",setnew)'''
'''2: Return a new set of identical items from two sets'''
'''lst1=[]
lst2=[]
for i in range(5):
    items=int(input("Enter the items to be added to the set"))
    lst1.append(items)
set1=set(lst1)
print(set1)
for i in range(5):
    item=int(input("Enter the items to be added to set"))
    lst2.append(item)
set2=set(lst2)
print(set2)
setnew=set1.intersection(set2)
print("The set containing similar items are:",setnew)'''
            
'''3: Get Only unique items from two set'''
'''lst1=[]
lst2=[]
for i in range(6):
    items=int(input("Enter the items to be added to the set"))
    lst1.append(items)
set1=set(lst1)
print(set1)
for i in range(6):
    item=int(input("Enter the items to be added to set"))
    lst2.append(item)
set2=set(lst2)
print(set2)
setnew=set1.symmetric_difference(set2)
print(setnew)'''

'''4: Update the first set with items that don’t exist in the second set'''
'''lst1=[]
lst2=[]
for i in range(5):
    items=int(input("Enter the items to be added to the set"))
    lst1.append(items)
set1=set(lst1)
print(set1)
for i in range(5):
    item=int(input("Enter the items to be added to set"))
    lst2.append(item)
set2=set(lst2)
print(set2)
set1.symmetric_difference_update(set2)
print("The updated set is:",set1)'''

'''Remove items from the set at once'''
'''lst1=[]
for i in range(5):
    items=int(input("Enter the items to be added to the set"))
    lst1.append(items)
set1=set(lst1)
print(set1)
item=int(input("enter the element to be removed"))
set1.remove(item)
print("The edited set is:",set1)'''

'''6: Return a set of elements present in Set A or B, but not both'''
'''lst1=[]
lst2=[]
for i in range(6):
    items=int(input("Enter the items to be added to the set"))
    lst1.append(items)
setA=set(lst1)
print(setA)
for i in range(6):
    item=int(input("Enter the items to be added to set"))
    lst2.append(item)
setB=set(lst2)
print(setB)
setC=setA.symmetric_difference(setB)
print("The set of elements present in Set A or B, but not both are:",setC)'''

'''7: Check if two sets have any elements in common. If yes, display the common elements'''
'''lst1=[]
lst2=[]
for i in range(5):
    items=int(input("Enter the items to be added to the set"))
    lst1.append(items)
setA=set(lst1)
print(setA)
for i in range(5):
    item=int(input("Enter the items to be added to set"))
    lst2.append(item)
setB=set(lst2)
print(setB)
setnew=setA.intersection(setB)
for common in setnew:
    print("The common elements are:",common)'''


'''8: Update set1 by adding items from set2, except common items'''
'''lst1=[]
lst2=[]
for i in range(5):
    items=int(input("Enter the items to be added to the set"))
    lst1.append(items)
setA=set(lst1)
print(setA)
for i in range(5):
    item=int(input("Enter the items to be added to set"))
    lst2.append(item)
setB=set(lst2)
print(setB)
setA.symmetric_difference_update(setB)
print("The updated set is:",setA)'''
'''9: Remove items from set1 that are not common to both set1 and set2'''
'''lst1=[]
lst2=[]
for i in range(5):
    items=int(input("Enter the items to be added to the set"))
    lst1.append(items)
setA=set(lst1)
print(setA)
for i in range(5):
    item=int(input("Enter the items to be added to set"))
    lst2.append(item)
setB=set(lst2)
print(setB)
setC=setA.symmetric_difference(setB)
for items in setC:
    if items in setA:
        setA.remove(items)
print("The edited set is:",setA)'''

'''10.Write a Python program to check if a given set is a superset of itself and a superset
of another given set.'''
'''lst1=[]
lst2=[]
for i in range(5):
    items=int(input("Enter the items to be added to the set"))
    lst1.append(items)
setA=set(lst1)
print(setA)
for i in range(5):
    item=int(input("Enter the items to be added to set"))
    lst2.append(item)
setB=set(lst2)
print(setB)
if(setA.issuperset(setB)==True):
    print("Set A is a superset of SetB")
else:
    print("Set A is  not a superset of SetB")

if(setA.issuperset(setA)==True):
    print("Set A is a superset of itself")
else:
    print("Set A is  not a superset of itself")'''

#Dictionary
'''1. Convert two lists into a dictionary'''
'''lst1=[]
lst2=[]
for i in range(5):
    items=int(input("Enter the items to be added to the dictionary"))
    lst1.append(items)
print(lst1)
for i in range(5):
    item=input("Enter the items to be added to dictionary")
    lst2.append(item)
print(lst2)
newdict=dict(zip(lst1,lst2))
print("The converted dictionary is :",newdict)'''

'''2. Merge two Python dictionaries into one'''
'''lst1=['name','id','marks','phoneno']
lst11=['email','credits','cgpa','grade']
lst2=[]
lst3=[]
print("Enter name,id,marks,phoneno,email,credits,cgpa,grade")
for i in range(4):
    items=input("Enter the items to be added to the set")
    lst2.append(items)
for i in range(4):
    item=input("Enter the items to be added to set")
    lst3.append(item)
dict1=dict(zip(lst1,lst2))
print("The first dictionary is",dict1)
dict2=dict(zip(lst11,lst3))
print("The second dictionary is",dict2)
dict1.update(dict2)
print("The merged dictionary is",dict1)'''

'''3. Print the value of key ‘history’ from the below dict'''
'''sublst=['math','science','history','english','language']
lst2=[]
print("Enter the marks for math,science,history,english,language")
for i in range(5):
    items=int(input("Enter the items to be added to the dictionary"))
    lst2.append(items)
dict1=dict(zip(sublst,lst2))
print("the value of key ‘history’ is:",dict1["history"])'''

'''4. Initialize dictionary with default values'''
'''lst1=[ 'name','id','grade']
lst2=[]
print("Enter the name, Id, grade")
for i in range(3):
    item=input("Enter the items to be added to dictionary")
    lst2.append(item)
newdict=dict(zip(lst1,lst2))
print(newdict)
default=int(input("Enter the default values"))
dictobj=dict.fromkeys(newdict,default)
print(dictobj)'''

'''5. Create a dictionary by extracting the keys from a given dictionary'''
'''lst1=[ 'name','id','grade']
lst2=[]
finalst=[]
keyslst=[]
print("Enter the name, Id, grade")
for i in range(3):
    item=input("Enter the items to be added to dictionary")
    lst2.append(item)
newdict=dict(zip(lst1,lst2))
print(newdict)
for items in newdict.keys():
    keyslst.append(items)
    element=input("Enter the items to be added to dictionary")
    finalst.append(element)
finaldict=dict(zip(keyslst,finalst))
print(finaldict)'''

'''6. Delete a list of keys from a dictionary'''
'''lst1=['course','fee','Duration','discount']
lst2=[]
print("Enter the course,fees,duration,discount")
for i in range(4):
    item=input("Enter the items to be added to dictionary")
    lst2.append(item)
newdict=dict(zip(lst1,lst2))
print(newdict)
for i in range(3):
    keys=input("Enter the keys to be removed")
    del newdict[keys]
print("The dictionary after removing the keys:",newdict)'''


'''7. Check if a value exists in a dictionary'''
'''lst1=['course','fee','Duration','discount']
lst2=[]
lstkey=[]
print("Enter the course,fees,duration,discount")
for i in range(4):
    item=input("Enter the items to be added to dictionary")
    lst2.append(item)
newdict=dict(zip(lst1,lst2))
print(newdict)
value=input("Enter the value that has to be checked in the dictionary")
for x in newdict.values():
    lstkey.append(x)
if value  in lstkey:
    print(value,"is present")
else:
    print(value,"not present")'''
    
'''8. Rename key of a dictionary'''
'''lst1=['course','fee','Duration','discount']
lst2=[]
print("Enter the course,fees,duration,discount")
for i in range(4):
    item=input("Enter the items to be added to dictionary")
    lst2.append(item)
newdict=dict(zip(lst1,lst2))
print(newdict)
key=input("Enter the value that has to be remamed in the dictionary")
keychange=input("Enter the value to be renamed to")
newdict[keychange]=newdict[key]
del newdict[key]
print("enter the edited dictionary is:",newdict)
print("The dictionary after removing the required key",newdict)'''

'''9. Get the key of a minimum value from the following dictionary'''
'''lst1=[]
lst2=[]
for i in range(5):
    items=input("Enter the items to be added to the dictionary")
    lst1.append(items)
for i in range(5):
    item=input("Enter the items to be added to dictionary")
    lst2.append(item)
newdict=dict(zip(lst1,lst2))
print("The converted dictionary is :",newdict)
x=min(newdict.values())
print("The minimum value in the dictionary is",x)
res=[key for key in newdict if newdict[key]==x]
print(" The key of the minimum value is:",res)'''

'''Change value of a key in a nested dictionary'''
Employee = { 
    'emp1': {
        'name': 'Lisa', 
        'age': '29',
        'Designation':'Programmer'
            }, 
    'emp2': {
             'name': 'Steve',
             'age': '45',
             'Designation':'HR'
             }
}
print(Employee)
empno=input("Enter the employee number(1,2)")
print(empno)
changekey=input("Enter the key to be changed")
print(changekey)
changedvalue=input("Enter the value to be changed to")
print(changedvalue)
Employee[empno][changekey]=changedvalue
print("The edited dictionary is",Employee)
                
    

