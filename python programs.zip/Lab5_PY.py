#Lab 5
#Inheritance

'''1. Create a base class LibraryItem with attributes title, author, and publication_year.
Include a method display_info() to display the details of the item.
Create subclasses for different types of library items like Book, Magazine, and DVD.
Implement methods specific to each subclass for displaying their information.'''


class LibraryItem:
    def __init__(self, title, author, publication_year):
        self.title = title
        self.author = author
        self.publication_year = publication_year

    def display_info(self):
        print(f"Title: {self.title}")
        print(f"Author: {self.author}")
        print(f"Publication Year: {self.publication_year}")

class Book(LibraryItem):
    def __init__(self, title, author, publication_year, isbn):
        super().__init__(title, author, publication_year)
        self.isbn = isbn

    def display_info(self):
        super().display_info()
        print(f"ISBN: {self.isbn}")

class Magazine(LibraryItem):
    def __init__(self, title, author, publication_year, issue_number):
        super().__init__(title, author, publication_year)
        self.issue_number = issue_number

    def display_info(self):
        super().display_info()
        print(f"Issue Number: {self.issue_number}")

class DVD(LibraryItem):
    def __init__(self, title, author, publication_year, duration):
        super().__init__(title, author, publication_year)
        self.duration = duration

    def display_info(self):
        super().display_info()
        print(f"Duration: {self.duration} minutes")

# Creating instances of the subclasses
book = Book("The Great Gatsby", "F. Scott Fitzgerald", 1925, "978-3-16-148410-0")
magazine = Magazine("National Geographic", "National Geographic Society", 1888, "August 2023")
dvd = DVD("Inception", "Christopher Nolan", 2010, 148)

# Displaying information using the display_info() method
print("Book Information:")
book.display_info()
print("\nMagazine Information:")
magazine.display_info()
print("\nDVD Information:")
dvd.display_info()



'''2.Create a base class Product with attributes name, price, and quantity.
Create two subclasses: PhysicalProduct and DigitalProduct.
PhysicalProduct should have an additional attribute weight, and
DigitalProduct should have an attribute file_size.
Implement methods to calculate the total cost of physical and digital products,
considering shipping costs for physical products.'''


'''class Product:
    def __init__(self, name, price, quantity):
        self.name = name
        self.price = price
        self.quantity = quantity

    def calculate_total_cost(self):
        return self.price * self.quantity

class PhysicalProduct(Product):
    def __init__(self, name, price, quantity, weight):
        super().__init__(name, price, quantity)
        self.weight = weight

    def calculate_total_cost(self, shipping_cost_per_kg):
        product_cost = super().calculate_total_cost()
        shipping_cost = shipping_cost_per_kg * self.weight
        total_cost = product_cost + shipping_cost
        return total_cost

class DigitalProduct(Product):
    def __init__(self, name, price, quantity, file_size):
        super().__init__(name, price, quantity)
        self.file_size = file_size

# Creating instances of the subclasses
physical_product = PhysicalProduct("Book", 20, 2, 1.5)
digital_product = DigitalProduct("Ebook", 10, 3, "5 MB")

# Calculating total costs
shipping_cost_per_kg = float(input("Enter the shipping cost: "))
physical_total_cost = physical_product.calculate_total_cost(shipping_cost_per_kg)
digital_total_cost = digital_product.calculate_total_cost()

# Displaying total costs
print(f"Total cost of physical product(Book): ${physical_total_cost:.2f}")
print(f"Total cost of digital product(EBook): ${digital_total_cost:.2f}")'''


#Exception Handling
'''1. Write a program that repeatedly prompts the user to enter a number.
If the user presses Ctrl+C, catch the KeyboardInterrupt exception and
display a message indicating that the program was interrupted.'''

try:
    while True:
        try:
            number = float(input("Enter a number: "))
            print(f"You entered: {number}")
        except ValueError:
            print("Invalid input. Please enter a valid number.")
except KeyboardInterrupt:
    print("\nProgram was interrupted.")

'''2.Write a program that defines a dictionary with some key-value pairs.
Prompt the user to enter a key and then display the corresponding value.
Handle the case where the user enters a key that doesn't exist in the dictionary by
displaying an error message.'''

# Define a dictionary with key-value pairs
'''data_dictionary = {"apple": "A fruit that is red or green and is delicious.",
                   "banana": "A long, curved fruit that is yellow when ripe.",
                   "orange": "A citrus fruit that is typically orange in color."}

# Prompt the user to enter a key
try:
    while True:
        user_input = input("Enter a key: ")
        if user_input in data_dictionary:
            print(f"Value for '{user_input}': {data_dictionary[user_input]}")
        else:
            print(f"Key '{user_input}' not found in the dictionary.")
except KeyboardInterrupt:
    print("\nProgram was interrupted.")'''
