i=0
while(i<=6):
    if(i%3==0):
        pass
    else:
        print(i)
    i+=1
