n=int(input("Enter the number to be printed"))
i=1
f1=0
f2=1
print(f1)
print(f2)
while(i<=n):
    f3=f1+f2
    print(f3)
    f1=f2
    f2=f3
    i+=1
    
