i=10
while(i<=20):
    if(i%5==0):
        print(i)
    i+=1
