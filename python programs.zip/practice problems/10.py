no_of_class_held=int(input("Enter the number of classes held"))
no_of_class_attended=int(input("enter the number of classes attended"))
per=(no_of_class_attended/no_of_class_held)*100
print("Your attendance is:",per)
if(per>=75):
    print("You are allowed to sit for exam")
else:
    print("You are not allowed to sit for exam")
