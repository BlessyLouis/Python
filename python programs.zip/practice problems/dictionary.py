dict={"name":"Blessy","id":16,"sal":33000}
print(len(dict))
print(dict.get("name"))
x=dict.keys()
print(x)

