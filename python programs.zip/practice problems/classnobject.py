'''class class1:
    x=50
c1=class1()
print(c1.x)'''

'''class class2:
    def __init__(self,a,b):
        self.n1=a
        self.n2=b

k=class2(5,6)
print(k.n1)'''

class students:
    def __init__(self,stname,stage,marks):
        self.name=stname
        self.age=stage
        self.marks=marks
    def __str__(self):
        return f"{self.name},{(self.age)},{self.marks}"
p1=students("Blessy",21,87)
print(p1)
    
