'''Write a Python program to count the number of strings from a given list of strings.
The string length is 2 or more and the first and last characters are the same.'''
'''import string
samplelst=['abc','xyz','aba','1221']
count=0
for items in samplelst:
    l=items.partition(items[1])
    if(len(items)>=2 and items.endswith(items[0]) ):
        count=count+1
print(count)'''

'''Write a Python program to remove an item from a tuple.'''
'''tup=('Blessy',101,'MDS B',78,'Pass')
tuplst=list(tup)
pos=int(input("Enter the position of the item to be removed:"))
tuplst.remove(tuplst[pos])
tup=tuple(tuplst)
print("The edited tuple is", tup)'''
    
'''2. Write a Python program to find the list of words that are longer than n from a given
list of words.'''
'''lstname=['Blessy','Anuneetha','Yukthi','Regina','Melwin','Beaulah','Diana','Anusha','Iyleen','Dhruv']
n=int(input("Enter the maximum length of string"))
lstnew=[]
for item in lstname:
    if(len(item)>n):
        lstnew.append(item)
print("The list of words longer than the maximum limit are:")
print(lstnew)'''

'''3. Write a Python function that takes two lists and returns True if they have at least
one common member.'''
'''lst_1=[]
lst_2=[]
for i in range(5):
    num1=int(input("Enter the numbers of list 1"))
    lst_1.append(num1)
for j in range(5):
    num2=int(input("enter the numbers of list 2"))
    lst_2.append(num2)
count=0
for item in lst_1:
    for element in lst_2:
        if(item==element):
            count=count+1
if(count>=1):
    print("TRUE")
else:
    print("FALSE")'''

'''4. Write a Python program to print a specified list after removing the 0th, 4th and 5th
elements.'''

'''sample=['red','green','white','black','pink','yellow']
sample.remove(sample[0])
sample.remove(sample[3])
sample.remove(sample[3])
print(sample)'''

'''5. Write a Python program to print the numbers of a specified list after removing even
numbers from it.'''
'''lst=[]
for i in range(5):
    num=int(input ("Enter the numbers to be added to the list"))
    lst.append(num)
for items in lst:
    if(items%2==0):
        lst.remove(items)
print(lst)'''

'''6. Write a Python program to get a list, sorted in increasing order
by the last element in each tuple from a given list of non-empty
tuples.'''

'''samplelst=[(2,5),(1,2),(4,4),(2,3),(2,1)]
newlst=[]
n=len(samplelst)
for i in  range(0,n):
    for j in range(0,n-i-1):
        if(samplelst[j][-1]>samplelst[j+1][-1]):
            temp=samplelst[j]
            samplelst[j]=samplelst[j+1]
            samplelst[j+1]=temp
                                
print(samplelst)'''

'''Write a Python program to replace the last value of tuples in a
list.'''
'''numlst=[(10,20,40),(40,50,60),(70,80,90)]
print(numlst)
newlst=[]
n=int(input("Enter the number to be changed to"))
for items in numlst:
    lst=list(items)
    lst[2]=n
    t=tuple(lst)
    newlst.append(t)

print(newlst)'''
    
    


    
    


    


