Nest_list=[["Blessy","louis"],21,["computer", "mathematics","statistics"]]
print(len(Nest_list))
print(len(Nest_list[0]))
print(Nest_list[2][2])
tup=(12,"Blessy",20)
print(len(tup))
print(type(tup))
x=1
y=2
(x,y)=(y,x)
print(x,y)

tup1=(13, "Anu",21)
print(tup + tup1)
print(tup1*3)
