for i in range (-2,-5,-1):
    print(i,end=" ")
