n=int(input("enter the number"))
f1=0
f2=1
print(f1)
print(f2)
for x in range(n):
    f3=f1+f2
    print(f3)
    f1=f2
    f2=f3
    
