s='abcdefdefabc'
'''print(s.index('abc'))
print(s.find('def'))
print(s.rfind('de'))
print(s.rindex('a'))
print(s.index('abd'))'''
print(s.rfind('abd'))
s1='abcdefghi'
print(s1.startswith('a'))
print(s1.startswith('abc'))
print(s1.endswith('d'))
print(s1.endswith('hi'))
print(s1.startswith(('abc','def')))
print(s1.startswith(('a','b','c')))
print(s1.endswith(('ghi','hi','i')))
s2='AbC'
print(s2.upper())
print(s2.lower())
print(s2.swapcase())
s3='abc'
print(s3.ljust(5))
print(s3.rjust(6))
s4=' abc\n\t'
print(s4.rstrip())
print(s4.strip())
      
