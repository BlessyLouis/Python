n=int(input("Enter any number"))
i=1
while(i<=n):
    j=1
    while(j<=i):
        print(i,end=" ")
        j+=1
    print()
    i+=1
    
