#1
'''try:
    print(x)
except:
    print("An exception occured")'''

#2
'''try : 
    print(x)
except NameError:
    print("Variables x is not defined")
except:
    print("Something else went wrong")'''
#3
'''try:
    print("Hello")
except:
    print("Something went wrong")
else:
    print("Nothing went wrong")'''

#4
'''try:
    print(x)
except:
    print("something went wrong")
finally:
    print("The 'try except' is finished")'''

#5
'''x=-1
if x<0:
    raise Exception("sorry,no numbers below zero")'''

# Regular expression
#1

'''import re
txt= "The rain in Spain"
x=re.search("^The .*Spain$",txt)
if x:
    print("Yes! we have a match")
else:
    print("No Match")'''
#2
'''import re
txt="The rain in Spain"
x=re.findall("ai",txt)
print(x)'''
#3
'''import re
txt="the rain in spain"
x=re.findall("Portugal",txt)
print(x)
if(x):
    print("Yes, There is at least one match")
else:
    print("No match")'''

#4
'''import re
txt="The rain in spain"
x=re.search("\s",txt)
print("The first white-space character is located in the position:",x.start())'''

#5
'''import re
txt="The rain in Spain"
x=re.search("\s",txt)
print(x)
print("The first white_space character is located in position ",x.start())'''

#6
'''import re
txt="the rain in Spain"
x=re.split("\s",txt,1)
print(x)'''

import re
txt="The rain in spain"
x=re.sub("\s","9",txt)
print(x)
