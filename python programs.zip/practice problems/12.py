cel_deg=int(input("Enter the celsius degree"))
fah_deg=(cel_deg*(9/5))+32
print(cel_deg,"C is",fah_deg,"in Fahrenheit")

