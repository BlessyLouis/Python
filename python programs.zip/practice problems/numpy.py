import numpy as np
np.array([10,45,78,90,23,36,94],dtype='float32')
