length=int(input("Enter the length"))
breadth=int(input("Enter the breadth"))
if(length==breadth):
    print("This is a square")
else:
    print("This is not a square")
          

           
