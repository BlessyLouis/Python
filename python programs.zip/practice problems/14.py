i=1
while(i<=50):
    if(i%3==0):
        print("FIZZ")
    elif(i%5==0):
        print("BUZZ")
    elif(i%3==0 and i%5==0):
        print("FizzBuzz")
    else:
        print(i)
    i+=1
    
    
