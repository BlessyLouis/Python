sal=int(input("Enter your salary"))
yr_ser=int(input("Enter the number of years of service"))
if(yr_ser>=5):
    print("Your bonus amount is :",yr_ser*sal)
else:
    print("No Bonus")
        
