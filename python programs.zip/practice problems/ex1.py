''' int is used to convert the string to integer '''
'''F_no=int(input("Enter a number"))
S_no=int(input("Enter a second number"))
Result=F_no+S_no
print("Result",Result)'''

'''num1=num2=num3=4
print(num1)
print(num2)
print(num3)'''

x,y,z=5,'Python',5.6
print(x)
print(y)
print(z)
