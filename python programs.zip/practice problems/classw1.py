''' write a python program to find the numbers that are even or old and put them in the separate list'''
#list_1=[12,34,56,78,90,13,46,78,91,22,22,34,78,90]
'''list_2=[]
list_3=[]'''
'''for i in range(0,15):
    if(list_1[i] % 2 == 0):
        list_2.append(list_1[i])
print(list_2)

    if(list_1[i] == list_1[i+1]):
        list_1.remove(list_1[i+1])
print(list_1)'''


'''for i in list_1:
    print(i)

for i in range(len(list_1)):
    print(i)'''

'''a=4
b=22
#if a>b: print("a is greater")
print("a is smaller" ) if a<b else print("a is greatwer")'''

'''fruits=["apple","banana","cherry","kiwi","mango"]
newlist=[x for x in fruits if "a" in x]
print(newlist)'''

'''for i in list_1:
    for j in range(14):
        if list_1[j] > list_1[i]:
           t=list_1[j]
           list_1[j] = list_1[i]
           list_1[i]=t
        
print(list_1)'''

'''circle_area=lambda r :(r**2)*3.14
area=circle_area
r =int(input("enter the radius of circle"))
print(area(r))'''
       
f=lambda x,y,z=0,w=0: x+2*y+3*z+4*w
print(f(1,2))
print(f(1,2,z=10))

    
