i=1500
while(i<=2700):
    if(i%7==0 and i%5==0):
        print(i)

    i+=1
