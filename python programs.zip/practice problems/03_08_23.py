'''Write a python function for the following:'''
'''a. a function prodDigits() that inputs a number and returns the product of digits of that number.
def getProduct(n):
  
    product = 1
  
    while (n != 0):
        product = product * (n % 10)
        n = n // 10
  
    return product
  

n = int(input("Enter any number"))
if(n<=9):
    print("Enter a 2 or more digited number")
else:
    print(getProduct(n))'''


''' A number is called perfect if the sum of proper divisors of that number is equal to the number. For example 28 is perfect number, since 1+2+4+7+14=28. Write a program to print all the perfect numbers in a given range'''
'''lowerLimit = int(input("Please input the lower limit: "))
upperLimit = int(input("Please input the upper limit: "))
print("The Perfect number is: ")
for i in range(lowerLimit, upperLimit + 1):
    sum1 = 0
    for j in range(1, i):
        if i % j == 0:
            sum1 += j
    if  sum1 == i:
        print(i)
print()'''

''' Write a function that inputs a number and prints the multiplication table of that number.'''

def multable(number):
    for i in range(1,11): 
        print(number,' x ', i, ' = ',number*i) 
n = int(input("Please Enter a number to print its multiplication table:"))
multable(n)
    
''' Write the inference from the string methods and math methods'''
