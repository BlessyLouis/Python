n=int(input("Enter any number"))
i=1
while(i<=n):
    print(i**2)
    i+=1
