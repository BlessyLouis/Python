list1=[11,34,56,20,34,99,67,90,14,-39,-800,-23]
for i in list1:
    if(i > 0 ):
        print (i, "is positive")
    else:
        print(i, "is negative")
    
           
list1=[11,34,56,20,34,99,67,90,14,-39,-800,-23]
for i in list1:
    if(i % 2 == 0 ):
        print (i, "is even")
    else:
        print(i, "is odd")
