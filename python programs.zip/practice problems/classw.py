list_name=[1,"blessy",20,"MDS B",2,"Anu",21,"MDSB"]
print(list_name)
print(len(list_name))
print(type(list_name))
print(list_name[1])
print(list_name[1 : 3])
print(list_name[-3 : -1])
'''if "blessy" in list_name:
    print("Yes, Blessy is present")
if "blessy" not in list_name:
    print("Blessy not present")'''
list_name[2]=21
print(list_name)
list_name[2 : 6]=[22,21]
list_name.append("No students")
list_name.insert(4,"pass")
print(list_name)
stud_list=[3,"yukthi",22,"Mba","pass"]
list_name.extend(stud_list)
print(list_name)
list_name.remove("pass")
print(list_name)
list_name.pop(6)
print(list_name)
del list_name[3]
print(list_name)
del stud_list
print(stud_list)
list_name.clear()
print(list_name)




