def multable(num):
    for i in range(11):
        res=num * i
        print(num ,"*" ,i," = ",res)
num=int(input("Enter any number to print the multiplication table of it:"))
if(num==0):
    print("Enter a number greater than 0")
else:
    multable(num)
    
