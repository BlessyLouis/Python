num=int(input("enter any   number"))
if(num%3==0 and num%5==0 and num%9==0):
            print("The number",num,"is divisible by 3,5,9")
else:
    print(" The number",num,"is not divisible by 3,5,9")
