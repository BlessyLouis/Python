age=int(input("Enter your age"))
if(age>=60):
    print(" You can avail the 50% off on the tickect price")
else:
    print("yor are not eligible to avail the 50% off")
            
