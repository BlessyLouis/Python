shape=input("enter a shape: triangle, circle and square")
if(shape=="triangle" or shape=="Triangle"):
    len=int(input("enter the length"))
    bred=int(input("enter the breadth"))
    print("Area of Trianle:",(1/2)*(len*bred))

elif(shape=="circle" or shape=="Cirle"):
    rad=int(input("enter the radius"))
    print("Area of a circle:",(3.14*(rad**2)))
else:
    side=int(input("Enter the length"))
    print("Area of a square is: ",side**2)        

