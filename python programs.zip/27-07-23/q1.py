digit=int(input("Enter a number: "))
if(digit<=99):
    digit//=10
    print(digit)

elif(digit>=100) and (digit<=999):
    digit//=100
    print(digit)

elif(digit>=1000) and (digit<=9999):
    digit//=1000
    print(digit)

elif(digit>=10000) and (digit<=99999):
    digit//=10000
    print(digit)
    
else:
    print("no")


    


           
