marks=int(input("Enter your marks"))
if(90<=marks<=100):
    print("Your grade is : A")
elif(80<=marks<90):
    print("Your grade is : B")
elif(70<=marks<80):
    print("Your grade is : C")
elif(60<=marks<50):
    print("Your grade is : D")
elif(50<=marks<40):
    print("Your grade is : D")
else:
    print("your grade is : F")
                      
                      
                  
