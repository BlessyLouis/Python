''' Demonstration of numpy aggregation using 1D array anf 2D array'''


import numpy as np
#x1=np.random.randint(50,size=35)
#print(x1)
x2 = np.random.randint(100, size=(8, 9))
'''print(x2)
#sum of elements in x1
print(np.sum(x1))
print(np.sum(x2))
#timeit np.sum(x1)'''

#reduce function
x3=np.random.randint(35,size=20)
'''print (x3)
print(np.add.reduce(x3))
print(np.multiply.reduce(x3))'''


#min max functions
'''print(np.min(x3),np.max(x3))'''

# min max functions for multi-dimensional array

'''x4=np.random.random((10,12))
#print(x4)
print(x4.min(axis=0))
print(x4.min(axis=1))
#print(x4.max(axis=0))
#print(x4.max(axis=1))'''
x5=np.arange(1,50)
'''print(x5)
print(np.prod(x5,axis=0))
print(np.mean(x5))
print(np.std(x5))
print(np.var(x5))
print(np.argmin(x5))
print(np.argmax(x5))

print(np.median(x5))
print(np.percentile(x5,95))
print(np.any(x5==0))
print(np.all(x5< 80))'''

print(np.nansum(x5))
print(np.nanprod(x5,axis=0))
print(np.nanmean(x5))
print(np.nanstd(x5))
print(np.nanvar(x5))
print(np.nanargmin(x5))
print(np.nanargmax(x5))
print(np.nanmin(x5))
print (np.nanmax(x5))  
print(np.nanmedian(x5))
print(np.nanpercentile(x5,95))
