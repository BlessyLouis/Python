'''Find the factorial of a given number'''

num=int(input("Enter the number for which the factorial is to be calculated"))
fact=1
if(num<0):
    print("Invalid Input")
elif(num==0):
    print("Factorial of 0 is 1")
else:
    
    for i in range(1,num +1,1):
        fact=fact * i
    print("Factorial of ",num,"is",fact)
   
  



        
