'''Write a program to print the cube of all numbers from 1 to a given number'''

number=int(input("Enter any number"))
if(number==0):
    print("enter a different number")
elif(number==-1):
    print("Enter a positive number")
else:
    for i in range(1,number + 1,1):
        print( i**3)
