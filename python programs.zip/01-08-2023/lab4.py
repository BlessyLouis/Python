'''Write a program to print the following start pattern using the for loop'''
rows=int(input("Enter the number of rows"))
for i in range(1,rows+1):
    print("*" * i)
for j in range(rows,0,-1):
    print("*" *(j-1))
    
   
