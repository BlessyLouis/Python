'''Display numbers from -10 to -1 using for loop'''
print("the numbers are")
for i in range(-10,0,1):
    print(i)
    
